package com.exemplo.algoritmos;

public class QuickSort {
    public static void ordenar(int[] array) {
        ordenar(array, 0, array.length - 1);
    }

    private static void ordenar(int[] array, int baixo, int alto) {
        if (baixo < alto) {
            int indicePivo = particionar(array, baixo, alto);
            ordenar(array, baixo, indicePivo - 1);
            ordenar(array, indicePivo + 1, alto);
        }
    }

    private static int particionar(int[] array, int baixo, int alto) {
        int pivo = array[(baixo + alto) / 2];
        int i = baixo - 1;
        int j = alto + 1;
        
        while (true) {
            do { i++; } while (array[i] < pivo);
            do { j--; } while (array[j] > pivo);
            
            if (i >= j) return j;
            
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }
}
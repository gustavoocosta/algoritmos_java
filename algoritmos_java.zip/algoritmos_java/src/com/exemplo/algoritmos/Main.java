package com.exemplo.algoritmos;

public class Main {
    public static void main(String[] args) {
        // Teste Busca Binária
        int[] numeros = {2, 3, 4, 10, 40};
        int alvo = 10;
        int resultado = BuscaBinaria.buscar(numeros, alvo);
        System.out.println("Busca binária: Índice do elemento " + alvo + " → " + resultado);

        // Teste Quick-Sort
        int[] arr = {10, 7, 8, 9, 1, 5};
        QuickSort.ordenar(arr);
        System.out.print("QuickSort: ");
        for (int num : arr) System.out.print(num + " ");
        System.out.println();

        // Teste Árvore Binária
        ArvoreBinaria arvore = new ArvoreBinaria();
        arvore.inserir(50);
        arvore.inserir(30);
        arvore.inserir(20);
        arvore.inserir(40);
        arvore.inserir(70);
        arvore.inserir(60);
        arvore.inserir(80);
        System.out.print("Árvore Binária (em ordem): ");
        arvore.emOrdem();
    }
}
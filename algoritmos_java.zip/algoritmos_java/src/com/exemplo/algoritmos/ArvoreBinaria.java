package com.exemplo.algoritmos;

public class ArvoreBinaria {
    static class No {
        int valor;
        No esquerda;
        No direita;

        public No(int valor) {
            this.valor = valor;
            esquerda = direita = null;
        }
    }

    No raiz;

    public void inserir(int valor) {
        raiz = inserirRec(raiz, valor);
    }

    private No inserirRec(No no, int valor) {
        if (no == null) return new No(valor);
        
        if (valor < no.valor) no.esquerda = inserirRec(no.esquerda, valor);
        else if (valor > no.valor) no.direita = inserirRec(no.direita, valor);
        
        return no;
    }

    public void emOrdem() {
        emOrdemRec(raiz);
    }

    private void emOrdemRec(No no) {
        if (no != null) {
            emOrdemRec(no.esquerda);
            System.out.print(no.valor + " ");
            emOrdemRec(no.direita);
        }
    }
}